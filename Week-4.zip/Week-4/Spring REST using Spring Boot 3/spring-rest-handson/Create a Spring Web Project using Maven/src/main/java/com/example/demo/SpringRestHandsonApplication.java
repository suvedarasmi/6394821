package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestHandsonApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringRestHandsonApplication.class, args);
    }
}
